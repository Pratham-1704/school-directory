var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/route.js")
R.c("server/chunks/node_modules_next_dist_e987a87e._.js")
R.c("server/chunks/node_modules_lodash_9f355569._.js")
R.c("server/chunks/node_modules_cloudinary_0ecd8ca6._.js")
R.c("server/chunks/node_modules_q_q_e1f26954.js")
R.c("server/chunks/[root-of-the-server]__461e6c63._.js")
R.m("[project]/.next-internal/server/app/api/upload/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/upload/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/upload/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
