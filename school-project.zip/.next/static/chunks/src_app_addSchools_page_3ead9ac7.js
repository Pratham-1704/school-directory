(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_b7726c08._.js",
  "static/chunks/src_app_addSchools_page_11ba4397.js"
],
    source: "dynamic"
});
