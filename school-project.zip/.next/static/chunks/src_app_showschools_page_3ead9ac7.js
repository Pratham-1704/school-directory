(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_antd_es_0785e5da._.js",
  "static/chunks/node_modules_rc-field-form_es_b5370d4f._.js",
  "static/chunks/node_modules_@ant-design_cssinjs_es_f1768631._.js",
  "static/chunks/node_modules_rc-tabs_es_cf9d1fcf._.js",
  "static/chunks/node_modules_rc-menu_es_4890bfa2._.js",
  "static/chunks/node_modules_378b3862._.js",
  "static/chunks/src_app_showschools_page_00275589.js"
],
    source: "dynamic"
});
